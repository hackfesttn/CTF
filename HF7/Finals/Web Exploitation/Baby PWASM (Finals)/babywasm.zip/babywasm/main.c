// main.wasm source :))


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <emscripten.h>

typedef struct {
  char protocol[0x8];
  char ip[0x20];
  char port[0x10];
  char path[0x20];
} info;

void read_input(char* buf) {
    int index = 0;
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF)
        buf[index++] = ch;
    buf[index] = '\0';
}

void parseInput(const char* input, char* protocol, char* ip, char* port, char* path) {
    sscanf(input, "%[^:]://%[^:]:%[^/]/%s", protocol, ip, port, path);
}

int is_valid_ip(const char* ip) {

    struct sockaddr_in sa;

    int result = inet_pton(AF_INET, ip, &(sa.sin_addr));
    if (result != 1) {
        return 0;
    }

    unsigned long ip_addr = ntohl(sa.sin_addr.s_addr);

    if ((ip_addr & 0xff000000) == 0x7f000000) {
        return 0;
    }

    if ((ip_addr & 0xff000000) == 0x0a000000 || 
        (ip_addr & 0xfff00000) == 0xac100000 || 
        (ip_addr & 0xffff0000) == 0xc0a80000) {
        return 0;
    }

    return 1;
}

size_t write_callback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t realsize = size * nmemb;
    char* output = (char*)userp;
    strncat(output, (char*)contents, realsize);
    return realsize;
}



char* checker(char* inp) {
    char protocol[0x8], ip[0x20], path[0x20], port[0x10];
    info *chunk = (info *) malloc(sizeof(info));

    
    parseInput(inp, protocol, ip, port, path);

    strncpy(chunk->protocol, protocol, 0x8);
    strncpy(chunk->ip, ip, 0x20);
    strncpy(chunk->port, port, 0x10);
    strncpy(chunk->path, path, 0x20);

    
    char url[128];
    char url1[200];

    

    snprintf(url, sizeof(url), "%s://%s:%s/%s", chunk->protocol, chunk->ip, chunk->port, chunk->path);
    
    if (!is_valid_ip(chunk->ip)){
    return "Not a valid URL";
    }
    if (strlen(inp) >= 50){
        return "Too long :()";
    }
    free(chunk);
    return url;
  

}
