import express from 'express';
import Module from './main.mjs';
import http from 'http';

const app = express();
function usercheck(str) {
    let slashCount = 0;
    let colonCount = 0;
    
    for(let i = 0; i < str.length; i++) {
        if(str[i] === '/') {
            slashCount++;
            if(slashCount === 3) {
                break;
            }
        } else if(str[i] === ':') {
            colonCount++;
            if(colonCount > 2) {
                return false;
            }
        }
    }
    
    if(slashCount < 3) {
        return -1;
    } else {
        return true;
    }
}


function getHTML(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        resolve(data);
      });
    });

    req.on('error', (error) => {
      reject(error);
    });
  });
}

const mod = await Module();

app.get('/check-url', async (req, res) => {
  const check_url = mod.cwrap('checker', 'string', ['string']);
  const url = req.query.url;
  if (!usercheck(url)){
   res.send("Too many colons")
   }
  const result = check_url(url);
  console.log(result);
  try {
    const html = await getHTML(result);
   
    res.send(html); 
  } catch (error) {
    console.error('Error fetching HTML:', error);
    res.status(500).send('Error fetching HTML');
  }
});

const port = 3000; 
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

setInterval(() => {
  console.log('Restarting application...');
  process.exit();
}, 10000);
