import express from 'express';

const app = express();


app.get('/flag', (req, res) => {
  
  res.send('flag{test}');
});

const port = 8080; 
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});

setInterval(() => {
  console.log('Restarting application...');
  process.exit();
}, 10000);

