<?php
define("SQLITE_DB_PATH", "/tmp/challenges.db");
$db = new SQLite3(SQLITE_DB_PATH);